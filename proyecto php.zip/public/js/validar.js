function validarFormulario() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if (email === "" || password === "") {
        alert("Todos los campos son obligatorios");
        return false;
    }
    return true;
}
