<form action="../controllers/AuthController.php" method="POST" onsubmit="return validarFormulario()">
    <input type="hidden" name="accion" value="login">

    <input type="email" name="email" id="email" placeholder="Correo">
    <input type="password" name="password" id="password" placeholder="Contraseña">

    <button type="submit">Ingresar</button>
</form>

<script src="../public/js/validar.js"></script>
