<?php
require_once "../config/database.php";
require_once "../models/User.php";

$db = (new Database())->connect();
$user = new User($db);

if ($_POST['accion'] == "registro") {
    $user->registrar($_POST['nombre'], $_POST['email'], $_POST['password']);
    header("Location: ../views/login.php");
}

if ($_POST['accion'] == "login") {
    session_start();
    $login = $user->login($_POST['email'], $_POST['password']);

    if ($login) {
        $_SESSION['usuario'] = $login['nombre'];
        header("Location: ../views/dashboard.php");
    } else {
        echo "Credenciales incorrectas";
    }
}
